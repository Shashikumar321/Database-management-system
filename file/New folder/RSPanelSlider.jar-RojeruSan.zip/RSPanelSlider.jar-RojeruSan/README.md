# RSPanelSlider
(Componente). Este es un JPanel personalizado en el cual se pueden poner más JPanel que pueden ir cambiando de acuerdo a un evento realizado

<img src="https://github.com/RojeruSan/RSPanelSlider/blob/master/Captura.PNG">

Puedes ayudarme con tus donaciónes para seguir creciendo, GRACIAS.<br>
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JLWEAETTE3H28" target="_blank">
<img src="https://www.paypalobjects.com/es_XC/MX/i/btn/btn_donateCC_LG.gif" 
alt="Donate" data-canonical-src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" style="max-width:100%;">
</a>
